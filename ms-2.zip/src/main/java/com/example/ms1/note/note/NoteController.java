package com.example.ms1.note.note;

import com.example.ms1.note.notebook.Notebook;
import com.example.ms1.note.notebook.NotebookRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/books/{notebookId}/notes")
public class NoteController {

    private final NoteRepository noteRepository;
    private final NotebookRepository notebookRepository;
    private final NoteService noteService;



    @PostMapping("/write")
    public String write(@PathVariable("notebookId") Long notebookId) {
        Notebook notebook = notebookRepository.findById(notebookId).orElseThrow();
        noteService.saveDefault(notebook);
        return "redirect:/";
    }

    @GetMapping("/{id}")
    public String detail(Model model, @PathVariable("notebookId") Long notebookId, @PathVariable("id") Long id) {
        Notebook notebook = notebookRepository.findById(notebookId).orElseThrow();
        List<Note> noteList = notebook.getNoteList();

        if (noteList.isEmpty()) {
            Note newNote = noteService.saveDefault(notebookRepository.findById(notebookId).orElseThrow());
            noteList.add(newNote);
            return "redirect:/";
        }
        //
        Note note = noteRepository.findById(id).get();

        // 노트북에 해당하는 노트 목록을 가져오기
        List<Notebook> notebookList = notebookRepository.findAll();
        Notebook targetNotebook = notebookRepository.findById(notebookId).get();



        //모델에 데이터 추간
        model.addAttribute("notebookList", notebookList);
        model.addAttribute("targetNotebook", targetNotebook);
        model.addAttribute("targetNote", note);
        model.addAttribute("noteList", noteList);

        return "main";
    }
    @GetMapping("/{id}/update")
    public String updateForm(@PathVariable("notebookId")Long notebookId,
                             @PathVariable("id")Long id, Model model) {
        Note note = noteRepository.findById(id).get();
        List<Notebook> notebookList = notebookRepository.findAll();
        Notebook targetNotebook = notebookRepository.findById(notebookId).get();
        List <Note> noteList = noteRepository.findByNotebook(targetNotebook);

        model.addAttribute("notebookList",notebookList);
        model.addAttribute("targetNotebook", targetNotebook);
        model.addAttribute("noteList", noteList);
        model.addAttribute("targetNote", note);
        return "main";
    }
    @PostMapping("/{id}/update")
    public String update(@PathVariable("notebookId") Long notebookId, @PathVariable("id") Long id,
                         String title, String content) {
        Note note = noteRepository.findById(id).orElseThrow();

        if(title.trim().length() == 0) {
            title = "제목 없음";
        }

        note.setTitle(title);
        note.setContent(content);
        noteRepository.save(note);
        return "redirect:/books/%d/notes/%d".formatted(notebookId, id);
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable("notebookId") Long notebookId,
                         @PathVariable("id") Long id) {
        noteRepository.deleteById(id);
        return "redirect:/";
    }


}